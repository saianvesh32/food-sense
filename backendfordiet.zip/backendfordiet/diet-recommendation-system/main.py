# # import streamlit as st
# # import pandas as pd
# # import pickle
# # import csv

# # # Load the model and dataset
# # with open('food_model.pickle', 'rb') as file:
# #     model = pickle.load(file)

# # food_data = pd.read_csv('done_food_data.csv')

# # # Helper function to read and sort CSV
# # def read_csv(file_path, sort_by='Descrip'):
# #     with open(file_path, 'r') as f:
# #         reader = csv.DictReader(f)
# #         rows = [row for row in reader]
# #         sorted_rows = sorted(rows, key=lambda x: x[sort_by])
# #         return sorted_rows

# # # Home Page
# # st.title("Food Recommendation System")
# # st.write("Welcome to the Food Recommendation System! Use the options below to predict or search food recommendations.")

# # # Tabs for Navigation
# # tab1, tab2, tab3, tab4, tab5 = st.tabs(["Home", "Predict", "Muscle Gain", "Weight Gain", "Weight Loss"])

# # # Home tab
# # with tab1:
# #     st.write("This is the home page. Navigate to other tabs for more functionalities.")

# # # Prediction Tab
# # with tab2:
# #     st.header("Predict Food Category")
# #     try:
# #         input_1 = st.number_input("Enter your daily calorie intake (Input 1):", step=0.1, format="%.2f")
# #         input_2 = st.number_input("Enter your daily protein intake (grams) (Input 2):", step=0.1, format="%.2f")
# #         input_3 = st.number_input("Enter your daily fat intake (grams) (Input 3):", step=0.1, format="%.2f")
        
# #         if st.button("Predict"):
# #             # Create an input array for the model
# #             inputs = [[input_1, input_2, input_3]]
# #             prediction = model.predict(inputs)

# #             # Format the prediction result
# #             if prediction[0] == 'Muscle_Gain':
# #                 result = 'Muscle Gain'
# #             elif prediction[0] == 'Weight_Gain':
# #                 result = 'Weight Gain'
# #             elif prediction[0] == 'Weight_Loss':
# #                 result = 'Weight Loss'
# #             else:
# #                 result = 'General Food'

# #             st.success(f"Prediction: {result}")
# #     except Exception as e:
# #         st.error("Invalid input values. Please enter valid numbers.")

# # # Filter Foods Functionality
# # def filter_foods(category, vegetarian, iron, calcium, anyfoods):
# #     data = food_data[food_data['category'] == category]
# #     if iron:
# #         data = data[data['Iron_mg'] > 6]
# #     if calcium:
# #         data = data[data['Calcium_mg'] > 150]
# #     if vegetarian:
# #         exclude_keywords = ['Egg', 'Fish', 'meat', 'beef', 'Chicken', 'Beef', 'Deer', 'lamb', 'crab', 'pork', 
# #                             'turkey', 'flesh', 'Frog legs', 'Ostrich', 'Emu', 'cuttlefish', 'Seaweed', 'crayfish', 
# #                             'shrimp', 'Octopus']
# #         data = data[~data['Descrip'].str.contains('|'.join(exclude_keywords), case=False)]
# #     return data

# # # Muscle Gain Tab
# # with tab3:
# #     st.header("Muscle Gain Foods")
# #     vegetarian = st.checkbox("I prefer vegetarian options only.", key="muscle_vegetarian")
# #     iron = st.checkbox("Show foods high in iron (greater than 6 mg).", key="muscle_iron")
# #     calcium = st.checkbox("Show foods high in calcium (greater than 150 mg).", key="muscle_calcium")
# #     anyfoods = st.checkbox("Include all types of foods.", key="muscle_anyfoods")

# #     if st.button("Show Muscle Gain Foods", key="muscle_button"):
# #         filtered_data = filter_foods('Muscle_Gain', vegetarian, iron, calcium, anyfoods)
# #         if not filtered_data.empty:
# #             st.write(filtered_data['Descrip'].sample(min(5, len(filtered_data))))
# #         else:
# #             st.warning("No foods match the selected criteria.")

# # # Weight Gain Tab
# # with tab4:
# #     st.header("Weight Gain Foods")
# #     vegetarian = st.checkbox("I prefer vegetarian options only.", key="weight_vegetarian")
# #     iron = st.checkbox("Show foods high in iron (greater than 6 mg).", key="weight_iron")
# #     calcium = st.checkbox("Show foods high in calcium (greater than 150 mg).", key="weight_calcium")
# #     anyfoods = st.checkbox("Include all types of foods.", key="weight_anyfoods")

# #     if st.button("Show Weight Gain Foods", key="weight_button"):
# #         filtered_data = filter_foods('Weight_Gain', vegetarian, iron, calcium, anyfoods)
# #         if not filtered_data.empty:
# #             st.write(filtered_data['Descrip'].sample(min(5, len(filtered_data))))
# #         else:
# #             st.warning("No foods match the selected criteria.")

# # # Weight Loss Tab
# # with tab5:
# #     st.header("Weight Loss Foods")
# #     vegetarian = st.checkbox("I prefer vegetarian options only.", key="loss_vegetarian")
# #     iron = st.checkbox("Show foods high in iron (greater than 6 mg).", key="loss_iron")
# #     calcium = st.checkbox("Show foods high in calcium (greater than 150 mg).", key="loss_calcium")
# #     anyfoods = st.checkbox("Include all types of foods.", key="loss_anyfoods")

# #     if st.button("Show Weight Loss Foods", key="loss_button"):
# #         filtered_data = filter_foods('Weight_Loss', vegetarian, iron, calcium, anyfoods)
# #         if not filtered_data.empty:
# #             st.write(filtered_data['Descrip'].sample(min(5, len(filtered_data))))
# #         else:
# #             st.warning("No foods match the selected criteria.")
# # import streamlit as st
# # import pandas as pd
# # import pickle
# # import csv

# # # Load the model and dataset
# # with open('food_model.pickle', 'rb') as file:
# #     model = pickle.load(file)

# # food_data = pd.read_csv('done_food_data.csv')

# # # Helper function to read and sort CSV
# # def read_csv(file_path, sort_by='Descrip'):
# #     with open(file_path, 'r') as f:
# #         reader = csv.DictReader(f)
# #         rows = [row for row in reader]
# #         sorted_rows = sorted(rows, key=lambda x: x[sort_by])
# #         return sorted_rows

# # # App Styles
# # st.markdown("""
# #     <style>
# #         body {
# #             background: linear-gradient(90deg, #e3ffe7 0%, #d9e7ff 100%);
# #             font-family: 'Arial', sans-serif;
# #         }
# #         .stButton>button {
# #             background-color: #4CAF50;
# #             color: white;
# #             border-radius: 10px;
# #             padding: 10px;
# #         }
# #         .stButton>button:hover {
# #             background-color: #45a049;
# #         }
# #         .stCheckbox>div {
# #             font-size: 1rem;
# #         }
# #         .result-box {
# #             border: 1px solid #4CAF50;
# #             border-radius: 10px;
# #             padding: 15px;
# #             margin: 10px 0;
# #             background-color: #f9fff7;
# #         }
# #     </style>
# # """, unsafe_allow_html=True)

# # # App Title
# # st.markdown("<h1 style='text-align: center; color: #2b6777;'>Food Recommendation System 🍴</h1>", unsafe_allow_html=True)
# # st.write("Welcome to the **Food Recommendation System**! Navigate through the tabs to find personalized food recommendations.")

# # # Tabs for Navigation
# # tab1, tab2, tab3, tab4, tab5 = st.tabs(["🏠 Home", "🔮 Predict", "💪 Muscle Gain", "📈 Weight Gain", "🔻 Weight Loss"])

# # # Home Tab
# # with tab1:
# #     st.markdown("<h2 style='text-align: center; color: #2b6777;'>Home 🏠</h2>", unsafe_allow_html=True)
# #     st.write("Explore other tabs for personalized food recommendations!")

# # # Filter Foods Functionality
# # def filter_foods(category, vegetarian, iron, calcium, anyfoods):
# #     data = food_data[food_data['category'] == category]
# #     if iron:
# #         data = data[data['Iron_mg'] > 6]
# #     if calcium:
# #         data = data[data['Calcium_mg'] > 150]
# #     if vegetarian:
# #         exclude_keywords = ['Egg', 'Fish', 'meat', 'beef', 'Chicken', 'Beef', 'Deer', 'lamb', 'crab', 'pork', 
# #                             'turkey', 'flesh', 'Frog legs', 'Ostrich', 'Emu', 'cuttlefish', 'Seaweed', 'crayfish', 
# #                             'shrimp', 'Octopus']
# #         data = data[~data['Descrip'].str.contains('|'.join(exclude_keywords), case=False)]
# #     return data

# # # Predict Tab
# # with tab2:
# #     st.markdown("<h2 style='color: #4CAF50;'>Predict Food Category 🔮</h2>", unsafe_allow_html=True)
# #     input_1 = st.number_input("Enter your daily calorie intake (kcal):", step=0.1, format="%.2f")
# #     input_2 = st.number_input("Enter your daily protein intake (grams):", step=0.1, format="%.2f")
# #     input_3 = st.number_input("Enter your daily fat intake (grams):", step=0.1, format="%.2f")

# #     if st.button("Predict Category"):
# #         try:
# #             inputs = [[input_1, input_2, input_3]]
# #             prediction = model.predict(inputs)
# #             result = {
# #                 'Muscle_Gain': 'Muscle Gain 💪',
# #                 'Weight_Gain': 'Weight Gain 📈',
# #                 'Weight_Loss': 'Weight Loss 🔻',
# #             }.get(prediction[0], 'General Food')
# #             st.success(f"Prediction: {result}")
# #         except Exception as e:
# #             st.error("Error in prediction. Please check your inputs!")

# # # Muscle Gain Tab
# # with tab3:
# #     st.markdown("<h2 style='color: #4CAF50;'>Muscle Gain Foods 💪</h2>", unsafe_allow_html=True)
# #     vegetarian = st.checkbox("Vegetarian options only", key="muscle_gain_vegetarian")
# #     iron = st.checkbox("High in Iron (> 6 mg)", key="muscle_gain_iron")
# #     calcium = st.checkbox("High in Calcium (> 150 mg)", key="muscle_gain_calcium")
# #     anyfoods = st.checkbox("Include all types of food", key="muscle_gain_anyfoods")

# #     if st.button("Find Foods for Muscle Gain"):
# #         results = filter_foods('Muscle_Gain', vegetarian, iron, calcium, anyfoods)
# #         if not results.empty:
# #             for food in results['Descrip'].sample(min(5, len(results))):
# #                 st.markdown(f"<div class='result-box'>{food}</div>", unsafe_allow_html=True)
# #         else:
# #             st.warning("No foods found matching your criteria.")

# # # Weight Gain Tab
# # with tab4:
# #     st.markdown("<h2 style='color: #4CAF50;'>Weight Gain Foods 📈</h2>", unsafe_allow_html=True)
# #     vegetarian = st.checkbox("Vegetarian options only", key="weight_gain_vegetarian")
# #     iron = st.checkbox("High in Iron (> 6 mg)", key="weight_gain_iron")
# #     calcium = st.checkbox("High in Calcium (> 150 mg)", key="weight_gain_calcium")
# #     anyfoods = st.checkbox("Include all types of food", key="weight_gain_anyfoods")

# #     if st.button("Find Foods for Weight Gain"):
# #         results = filter_foods('Weight_Gain', vegetarian, iron, calcium, anyfoods)
# #         if not results.empty:
# #             for food in results['Descrip'].sample(min(5, len(results))):
# #                 st.markdown(f"<div class='result-box'>{food}</div>", unsafe_allow_html=True)
# #         else:
# #             st.warning("No foods found matching your criteria.")

# # # Weight Loss Tab
# # with tab5:
# #     st.markdown("<h2 style='color: #4CAF50;'>Weight Loss Foods 🔻</h2>", unsafe_allow_html=True)
# #     vegetarian = st.checkbox("Vegetarian options only", key="weight_loss_vegetarian")
# #     iron = st.checkbox("High in Iron (> 6 mg)", key="weight_loss_iron")
# #     calcium = st.checkbox("High in Calcium (> 150 mg)", key="weight_loss_calcium")
# #     anyfoods = st.checkbox("Include all types of food", key="weight_loss_anyfoods")

# #     if st.button("Find Foods for Weight Loss"):
# #         results = filter_foods('Weight_Loss', vegetarian, iron, calcium, anyfoods)
# #         if not results.empty:
# #             for food in results['Descrip'].sample(min(5, len(results))):
# #                 st.markdown(f"<div class='result-box'>{food}</div>", unsafe_allow_html=True)
# #         else:
# #             st.warning("No foods found matching your criteria.")
# import streamlit as st
# import pandas as pd
# import pickle
# import csv

# # Load the model and dataset
# with open('food_model.pickle', 'rb') as file:
#     model = pickle.load(file)

# food_data = pd.read_csv('done_food_data.csv')

# # Helper function to read and sort CSV
# def read_csv(file_path, sort_by='Descrip'):
#     with open(file_path, 'r') as f:
#         reader = csv.DictReader(f)
#         rows = [row for row in reader]
#         sorted_rows = sorted(rows, key=lambda x: x[sort_by])
#         return sorted_rows

# # App Styles with Attractive Background
# st.markdown("""
#     <style>
#         body {
#             background: linear-gradient(135deg, #FFB6C1, #FFEB3B, #B0E0E6);
#             font-family: 'Arial', sans-serif;
#             padding: 0;
#             margin: 0;
#         }
#         .stButton>button {
#             background-color: #4CAF50;
#             color: white;
#             border-radius: 10px;
#             padding: 10px;
#         }
#         .stButton>button:hover {
#             background-color: #45a049;
#         }
#         .stCheckbox>div {
#             font-size: 1rem;
#         }
#         .result-box {
#             border: 1px solid #4CAF50;
#             border-radius: 10px;
#             padding: 15px;
#             margin: 10px 0;
#             background-color: #f9fff7;
#         }
#     </style>
# """, unsafe_allow_html=True)

# # App Title
# st.markdown("<h1 style='text-align: center; color: #2b6777;'>Food Recommendation System 🍴</h1>", unsafe_allow_html=True)
# st.write("Welcome to the **Food Recommendation System**! Navigate through the tabs to find personalized food recommendations.")

# # Tabs for Navigation
# tab1, tab2, tab3, tab4, tab5 = st.tabs(["🏠 Home", "🔮 Predict", "💪 Muscle Gain", "📈 Weight Gain", "🔻 Weight Loss"])

# # Home Tab
# with tab1:
#     st.markdown("<h2 style='text-align: center; color: #2b6777;'>Home 🏠</h2>", unsafe_allow_html=True)
#     st.write("Explore other tabs for personalized food recommendations!")

# # Filter Foods Functionality
# def filter_foods(category, vegetarian, iron, calcium, anyfoods):
#     data = food_data[food_data['category'] == category]
#     if iron:
#         data = data[data['Iron_mg'] > 6]
#     if calcium:
#         data = data[data['Calcium_mg'] > 150]
#     if vegetarian:
#         exclude_keywords = ['Egg', 'Fish', 'meat', 'beef', 'Chicken', 'Beef', 'Deer', 'lamb', 'crab', 'pork', 
#                             'turkey', 'flesh', 'Frog legs', 'Ostrich', 'Emu', 'cuttlefish', 'Seaweed', 'crayfish', 
#                             'shrimp', 'Octopus']
#         data = data[~data['Descrip'].str.contains('|'.join(exclude_keywords), case=False)]
#     return data

# # Predict Tab
# with tab2:
#     st.markdown("<h2 style='color: #4CAF50;'>Predict Food Category 🔮</h2>", unsafe_allow_html=True)
#     input_1 = st.number_input("Enter your daily calorie intake (kcal):", step=0.1, format="%.2f")
#     input_2 = st.number_input("Enter your daily protein intake (grams):", step=0.1, format="%.2f")
#     input_3 = st.number_input("Enter your daily fat intake (grams):", step=0.1, format="%.2f")

#     if st.button("Predict Category"):
#         try:
#             inputs = [[input_1, input_2, input_3]]
#             prediction = model.predict(inputs)
#             result = {
#                 'Muscle_Gain': 'Muscle Gain 💪',
#                 'Weight_Gain': 'Weight Gain 📈',
#                 'Weight_Loss': 'Weight Loss 🔻',
#             }.get(prediction[0], 'General Food')
#             st.success(f"Prediction: {result}")
#         except Exception as e:
#             st.error("Error in prediction. Please check your inputs!")

# # Muscle Gain Tab
# with tab3:
#     st.markdown("<h2 style='color: #4CAF50;'>Muscle Gain Foods 💪</h2>", unsafe_allow_html=True)
#     vegetarian = st.checkbox("Vegetarian options only", key="muscle_gain_vegetarian")
#     iron = st.checkbox("High in Iron (> 6 mg)", key="muscle_gain_iron")
#     calcium = st.checkbox("High in Calcium (> 150 mg)", key="muscle_gain_calcium")
#     anyfoods = st.checkbox("Include all types of food", key="muscle_gain_anyfoods")

#     if st.button("Find Foods for Muscle Gain"):
#         results = filter_foods('Muscle_Gain', vegetarian, iron, calcium, anyfoods)
#         if not results.empty:
#             for food in results['Descrip'].sample(min(5, len(results))):
#                 st.markdown(f"<div class='result-box'>{food}</div>", unsafe_allow_html=True)
#         else:
#             st.warning("No foods found matching your criteria.")

# # Weight Gain Tab
# with tab4:
#     st.markdown("<h2 style='color: #4CAF50;'>Weight Gain Foods 📈</h2>", unsafe_allow_html=True)
#     vegetarian = st.checkbox("Vegetarian options only", key="weight_gain_vegetarian")
#     iron = st.checkbox("High in Iron (> 6 mg)", key="weight_gain_iron")
#     calcium = st.checkbox("High in Calcium (> 150 mg)", key="weight_gain_calcium")
#     anyfoods = st.checkbox("Include all types of food", key="weight_gain_anyfoods")

#     if st.button("Find Foods for Weight Gain"):
#         results = filter_foods('Weight_Gain', vegetarian, iron, calcium, anyfoods)
#         if not results.empty:
#             for food in results['Descrip'].sample(min(5, len(results))):
#                 st.markdown(f"<div class='result-box'>{food}</div>", unsafe_allow_html=True)
#         else:
#             st.warning("No foods found matching your criteria.")

# # Weight Loss Tab
# with tab5:
#     st.markdown("<h2 style='color: #4CAF50;'>Weight Loss Foods 🔻</h2>", unsafe_allow_html=True)
#     vegetarian = st.checkbox("Vegetarian options only", key="weight_loss_vegetarian")
#     iron = st.checkbox("High in Iron (> 6 mg)", key="weight_loss_iron")
#     calcium = st.checkbox("High in Calcium (> 150 mg)", key="weight_loss_calcium")
#     anyfoods = st.checkbox("Include all types of food", key="weight_loss_anyfoods")

#     if st.button("Find Foods for Weight Loss"):
#         results = filter_foods('Weight_Loss', vegetarian, iron, calcium, anyfoods)
#         if not results.empty:
#             for food in results['Descrip'].sample(min(5, len(results))):
#                 st.markdown(f"<div class='result-box'>{food}</div>", unsafe_allow_html=True)
#         else:
#             st.warning("No foods found matching your criteria.")
import streamlit as st
import pandas as pd
import pickle
import csv

# Load the model and dataset
with open('food_model.pickle', 'rb') as file:
    model = pickle.load(file)

food_data = pd.read_csv('done_food_data.csv')

# Helper function to read and sort CSV
def read_csv(file_path, sort_by='Descrip'):
    with open(file_path, 'r') as f:
        reader = csv.DictReader(f)
        rows = [row for row in reader]
        sorted_rows = sorted(rows, key=lambda x: x[sort_by])
        return sorted_rows

# App Styles with Attractive Background
st.markdown("""
    <style>
        body {
            background: linear-gradient(135deg, #FFB6C1, #FFEB3B, #B0E0E6);
            font-family: 'Arial', sans-serif;
            padding: 0;
            margin: 0;
        }
        .stButton>button {
            background-color: #4CAF50;
            color: white;
            border-radius: 10px;
            padding: 10px;
        }
        .stButton>button:hover {
            background-color: #45a049;
        }
        .stCheckbox>div {
            font-size: 1rem;
        }
        .result-box {
            border: 1px solid #4CAF50;
            border-radius: 10px;
            padding: 15px;
            margin: 10px 0;
            background-color: #f9fff7;
        }
    </style>
""", unsafe_allow_html=True)

# App Title
st.markdown("<h1 style='text-align: center; color: #2b6777;'>Food Recommendation System 🍴</h1>", unsafe_allow_html=True)
st.write("Welcome to the **Food Recommendation System**! Navigate through the tabs to find personalized food recommendations.")

# Tabs for Navigation
tab1, tab2, tab3, tab4, tab5 = st.tabs(["🔮 Predict", "💪 Muscle Gain", "📈 Weight Gain", "🔻 Weight Loss", "📊 Dataset"])

# Predict Tab
with tab1:
    st.markdown("<h2 style='color: #4CAF50;'>Predict Food Category 🔮</h2>", unsafe_allow_html=True)
    input_1 = st.number_input("Enter your daily calorie intake (kcal):", step=10, format="%d")
    input_2 = st.number_input("Enter your daily protein intake (grams):", step=10, format="%d")
    input_3 = st.number_input("Enter your daily fat intake (grams):", step=10, format="%d")

    if st.button("Predict Category"):
        try:
            inputs = [[input_1, input_2, input_3]]
            prediction = model.predict(inputs)
            result = {
                'Muscle_Gain': 'Muscle Gain 💪',
                'Weight_Gain': 'Weight Gain 📈',
                'Weight_Loss': 'Weight Loss 🔻',
            }.get(prediction[0], 'General Food')
            st.success(f"Prediction: {result}")
        except Exception as e:
            st.error("Error in prediction. Please check your inputs!")

# Muscle Gain Tab
with tab2:
    st.markdown("<h2 style='color: #4CAF50;'>Muscle Gain Foods 💪</h2>", unsafe_allow_html=True)
    vegetarian = st.checkbox("Vegetarian options only", key="muscle_gain_vegetarian")
    iron = st.checkbox("High in Iron (> 6 mg)", key="muscle_gain_iron")
    calcium = st.checkbox("High in Calcium (> 150 mg)", key="muscle_gain_calcium")
    anyfoods = st.checkbox("Include all types of food", key="muscle_gain_anyfoods")

    if st.button("Find Foods for Muscle Gain"):
        results = filter_foods('Muscle_Gain', vegetarian, iron, calcium, anyfoods)
        if not results.empty:
            for food in results['Descrip'].sample(min(5, len(results))):
                st.markdown(f"<div class='result-box'>{food}</div>", unsafe_allow_html=True)
        else:
            st.warning("No foods found matching your criteria.")

# Weight Gain Tab
with tab3:
    st.markdown("<h2 style='color: #4CAF50;'>Weight Gain Foods 📈</h2>", unsafe_allow_html=True)
    vegetarian = st.checkbox("Vegetarian options only", key="weight_gain_vegetarian")
    iron = st.checkbox("High in Iron (> 6 mg)", key="weight_gain_iron")
    calcium = st.checkbox("High in Calcium (> 150 mg)", key="weight_gain_calcium")
    anyfoods = st.checkbox("Include all types of food", key="weight_gain_anyfoods")

    if st.button("Find Foods for Weight Gain"):
        results = filter_foods('Weight_Gain', vegetarian, iron, calcium, anyfoods)
        if not results.empty:
            for food in results['Descrip'].sample(min(5, len(results))):
                st.markdown(f"<div class='result-box'>{food}</div>", unsafe_allow_html=True)
        else:
            st.warning("No foods found matching your criteria.")

# Weight Loss Tab
with tab4:
    st.markdown("<h2 style='color: #4CAF50;'>Weight Loss Foods 🔻</h2>", unsafe_allow_html=True)
    vegetarian = st.checkbox("Vegetarian options only", key="weight_loss_vegetarian")
    iron = st.checkbox("High in Iron (> 6 mg)", key="weight_loss_iron")
    calcium = st.checkbox("High in Calcium (> 150 mg)", key="weight_loss_calcium")
    anyfoods = st.checkbox("Include all types of food", key="weight_loss_anyfoods")

    if st.button("Find Foods for Weight Loss"):
        results = filter_foods('Weight_Loss', vegetarian, iron, calcium, anyfoods)
        if not results.empty:
            for food in results['Descrip'].sample(min(5, len(results))):
                st.markdown(f"<div class='result-box'>{food}</div>", unsafe_allow_html=True)
        else:
            st.warning("No foods found matching your criteria.")

# Dataset Tab
with tab5:
    st.markdown("<h2 style='color: #4CAF50;'>Complete Dataset 📊</h2>", unsafe_allow_html=True)
    st.write("Here is the entire dataset of food items:")
    st.dataframe(food_data)
